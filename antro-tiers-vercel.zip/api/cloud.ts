// Vercel Serverless Function for Antro Tiers cloud sync.
//
// Endpoints (all handled by this single function via query params):
//   GET  /api/cloud            → public read (no auth) returns latest site data
//   GET  /api/cloud?status=1   → health probe: { kvConfigured, hasData }
//   PUT  /api/cloud            → write (X-Admin-Password header required)
//   POST /api/cloud?reset=1    → wipe cloud data (debug)
//
// Vercel routes /api/cloud* → api/cloud.ts automatically when the file is at
// api/cloud.ts, so /api/cloud/status is NOT a separate file — we use ?status=1.
//
// Uses Vercel KV (free tier). Connect a KV database to your Vercel project
// (Storage tab) and the KV_REST_API_URL/TOKEN env vars are auto-injected.

import type { VercelRequest, VercelResponse } from "@vercel/node";

const KV_KEY = "antro-tiers-data";
const DEFAULT_BOOTSTRAP_PASSWORD = "antro2025";

function getKv() {
  const url = process.env.KV_REST_API_URL || process.env.KV_URL;
  const token = process.env.KV_REST_API_TOKEN || process.env.KV_REST_API_READ_ONLY_TOKEN || process.env.KV_TOKEN;
  if (!url || !token) return null;
  // Normalize: KV_URL may end with /, strip it
  return { url: url.replace(/\/$/, ""), token };
}

async function kvGet<T = unknown>(): Promise<T | null> {
  const kv = getKv();
  if (!kv) return null;
  try {
    const res = await fetch(`${kv.url}/get/${KV_KEY}`, {
      headers: { Authorization: `Bearer ${kv.token}` },
    });
    if (!res.ok) return null;
    const j = await res.json();
    const raw = j?.result;
    if (raw == null) return null;
    return typeof raw === "string" ? JSON.parse(raw) : (raw as T);
  } catch {
    return null;
  }
}

async function kvSet(data: unknown): Promise<boolean> {
  const kv = getKv();
  if (!kv) return false;
  try {
    const res = await fetch(`${kv.url}/set/${KV_KEY}?EX=31536000`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${kv.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function kvDel(): Promise<boolean> {
  const kv = getKv();
  if (!kv) return false;
  try {
    const res = await fetch(`${kv.url}/del/${KV_KEY}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${kv.token}` },
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function parseBody(req: VercelRequest): Promise<any> {
  if (req.body && typeof req.body === "object") return req.body;
  return new Promise((resolve) => {
    let chunks = "";
    req.on("data", (c) => (chunks += c));
    req.on("end", () => {
      try { resolve(JSON.parse(chunks || "null")); } catch { resolve(null); }
    });
    req.on("error", () => resolve(null));
  });
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Admin-Password");
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  if (req.method === "OPTIONS") return res.status(200).end();

  const url = req.url || "";
  const wantStatus = url.includes("status=1");
  const wantReset = url.includes("reset=1");

  const kv = getKv();

  if (req.method === "GET" && wantStatus) {
    return res.status(200).json({
      kvConfigured: !!kv,
      hasData: !!(await kvGet()),
      service: "antro-tiers-cloud",
    });
  }

  if (!kv) {
    return res.status(503).json({
      error: "KV_NOT_CONFIGURED",
      message:
        "Vercel KV is not connected. In your Vercel project → Storage → Create/Connect a KV store → Redeploy.",
    });
  }

  // GET: public read
  if (req.method === "GET" && !wantStatus) {
    const data = await kvGet();
    if (!data) {
      return res.status(404).json({ error: "NO_DATA", message: "Cloud data not initialized yet." });
    }
    return res.status(200).json(data);
  }

  // PUT: authenticated write
  if (req.method === "PUT") {
    const providedPassword = String(req.headers["x-admin-password"] || "");
    if (!providedPassword) return res.status(401).json({ error: "NO_PASSWORD" });
    const body = await parseBody(req);
    if (!body || typeof body !== "object") return res.status(400).json({ error: "BAD_BODY" });
    const existing = await kvGet<{ adminPassword?: string } | null>();
    if (existing) {
      if (existing.adminPassword !== providedPassword) {
        return res.status(403).json({ error: "BAD_PASSWORD" });
      }
    } else {
      const payloadPw = body?.adminPassword;
      if (providedPassword !== DEFAULT_BOOTSTRAP_PASSWORD && providedPassword !== payloadPw) {
        return res.status(403).json({ error: "BOOTSTRAP_DENIED" });
      }
    }
    const ok = await kvSet(body);
    if (!ok) return res.status(500).json({ error: "KV_WRITE_FAILED" });
    return res.status(200).json({ ok: true, savedAt: Date.now() });
  }

  // POST/DELETE ?reset=1: wipe data
  if ((req.method === "POST" || req.method === "DELETE") && wantReset) {
    const providedPassword = String(req.headers["x-admin-password"] || "");
    const existing = await kvGet<{ adminPassword?: string } | null>();
    if (existing && existing.adminPassword !== providedPassword) {
      return res.status(403).json({ error: "BAD_PASSWORD" });
    }
    await kvDel();
    return res.status(200).json({ ok: true, reset: true });
  }

  return res.status(405).json({ error: "METHOD_NOT_ALLOWED" });
}
